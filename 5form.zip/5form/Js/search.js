// search.js

// 簡單搜尋函數
function searchCocktails() {
    const query = document.getElementById('search-input').value.toLowerCase();
    const resultsContainer = document.getElementById('search-results');
    resultsContainer.innerHTML = ''; // 清空先前的結果

    const filteredCocktails = cocktails.filter(cocktail => 
        cocktail.name.toLowerCase().includes(query)
    );

    if (filteredCocktails.length > 0) {
        filteredCocktails.forEach(cocktail => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `<a href="${cocktail.detailsPage}">${cocktail.name}</a>`;
            resultsContainer.appendChild(listItem);
        });
    } else {
        resultsContainer.innerHTML = '<li>未找到相關調酒。</li>';
    }
}

// 綁定搜尋按鈕
document.getElementById('search-button').addEventListener('click', searchCocktails);
