// cocktails.js

// 模擬的調酒數據（可從 JSON 文件或 API 獲取）
const cocktails = [
    {
        name: "中國藍 (China Blue)",
        sweetness: "甜",
        strength: "低",
        feeling: "沒有酒感",
        base: "伏特加",
        bubble: "要",
        image: "459894606c1bdadc4b44502fb981ebf3",
        detailsPage: "cocktailChinaBlue.html"
    },
    {
        name: "螺絲起子 (Screwdriver)",
        sweetness: "甜",
        strength: "低",
        feeling: "沒有酒感",
        base: "伏特加",
        bubble: "不要",
        image: "th(1)",
        detailsPage: "cocktailScrewdriver.html"
    },
    // ... 添加其他調酒 ...
];

// 函數：生成調酒列表
function displayCocktails() {
    const cocktailList = document.getElementById('cocktail-list');
    cocktails.forEach(cocktail => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `<a href="${cocktail.detailsPage}">${cocktail.name}</a>`;
        cocktailList.appendChild(listItem);
    });
}

// 初始化
document.addEventListener('DOMContentLoaded', displayCocktails);
