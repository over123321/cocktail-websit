// userProfile.js

// 模擬的用戶資料
const userProfile = {
    username: "張三",
    favorites: [
        "中國藍 (China Blue)",
        "威士忌可樂 (Whiskey Coke)",
        "龍舌蘭日出 (Tequila Sunrise)"
    ]
};

// 顯示用戶資料
function displayUserProfile() {
    document.getElementById('username').textContent = userProfile.username;
    const favoritesList = document.getElementById('favorites-list');
    userProfile.favorites.forEach(favorite => {
        const listItem = document.createElement('li');
        listItem.textContent = favorite;
        favoritesList.appendChild(listItem);
    });
}

// 初始化
document.addEventListener('DOMContentLoaded', displayUserProfile);
